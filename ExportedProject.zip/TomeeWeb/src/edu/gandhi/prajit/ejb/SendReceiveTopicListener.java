package edu.gandhi.prajit.ejb;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

/**
 * Message-Driven Bean implementation class for: SendReceiveTopicListener
 */
@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Topic") })
public class SendReceiveTopicListener implements MessageListener {
	public void onMessage(Message message) {
		if (message instanceof TextMessage) {
			System.out.println("Receiving Message From Topic:Start");
			try {
				System.out.println(" Received =>" + ((TextMessage) message).getText());
			} catch (JMSException ex) {
				System.out.println(" Received =>" + ex);
			}
			System.out.println("Receiving Message From Topic:End");
		} else {
			System.out.println("Receiving Message From Topic:Start");
			System.out.println("Not A Text Message");
			System.out.println("Receiving Message From Topic:End");
		}
	}
}
