package edu.gandhi.prajit.ejb;

import java.util.HashMap;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.jms.JMSException;
import javax.jws.WebService;

/**
 * Session Bean implementation class WebServiceExample
 */
@Stateless
@WebService
public class WebServiceExample {
	@EJB
	private Messages messages;

	public Map<String, String> getMessage() throws JMSException {
		Map<String, String> message = new HashMap<>();
		message.put("Latest Message", messages.receiveMessage());
		return message;
	}

	public Map<String, String> postMessage(String text) {
		Map<String, String> message = new HashMap<>();
		try {
			messages.sendMessage(text);
			message.put("Success", "True");
		} catch (JMSException e) {
			e.printStackTrace();
			message.put("Success", "False");
		}
		return message;
	}
}
