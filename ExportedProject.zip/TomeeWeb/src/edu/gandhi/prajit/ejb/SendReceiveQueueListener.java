package edu.gandhi.prajit.ejb;

import javax.annotation.Resource;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

/**
 * Message-Driven Bean implementation class for: SendReceiveQueueListener
 */
@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue") })
public class SendReceiveQueueListener implements MessageListener {
	@Resource
	private ConnectionFactory connectionFactory;
	public void onMessage(Message message) {
		if (message instanceof TextMessage) {
			System.out.println("Receiving Message From Queue:Start");
			try {
				System.out.println(" Received =>" + ((TextMessage) message).getText());
			} catch (JMSException ex) {
				System.out.println(" Received =>" + ex);
			}
			System.out.println("Receiving Message From Queue:End");
		} else {
			System.out.println("Receiving Message From Queue:Start");
			System.out.println("Not A Text Message");
			System.out.println("Receiving Message From Queue:End");
		}
	}
}
