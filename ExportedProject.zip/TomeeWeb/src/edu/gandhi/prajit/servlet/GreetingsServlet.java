package edu.gandhi.prajit.servlet;

import java.io.IOException;

import javax.ejb.EJB;
import javax.inject.Inject;
import javax.jms.JMSException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.gandhi.prajit.ejb.Messages;
import edu.gandhi.prajit.util.RandomUtil;

@WebServlet("/GreetingsServlet")
public class GreetingsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Inject
	private RandomUtil randomUtil;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

//		try {
//			Connection connection = connectionFactory.createConnection();
//			connection.start();
//			final Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
//			final Topic sendReceiveTopic = session.createTopic("SendReceiveTopic");
//			final MessageProducer producer = session.createProducer(sendReceiveTopic);
//			producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
//
//			final TextMessage message = session.createTextMessage(this.randomUtil.randomIdentifier());
//			message.setJMSCorrelationID(this.randomUtil.randomIdentifier());
//			message.setJMSDestination(sendReceiveTopic);
//			producer.send(message);
//			session.close();
//		} catch (JMSException e) {
//			e.printStackTrace();
//		}
//		try {
//			Connection connection = connectionFactory.createConnection();
//			connection.start();
//			final Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
//			Queue sendReceiveQueue = session.createQueue("SendReceiveQueue");
//			final MessageProducer producer = session.createProducer(sendReceiveQueue);
//			producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
//
//			final TextMessage message = session.createTextMessage(this.randomUtil.randomIdentifier());
//			message.setJMSCorrelationID(this.randomUtil.randomIdentifier());
//			message.setJMSDestination(sendReceiveQueue);
//			producer.send(message);
//			session.close();
//		} catch (JMSException e) {
//			e.printStackTrace();
//		}
		try {
			messages.sendMessage(randomUtil.randomIdentifier());
			System.out.println(messages.receiveMessage());
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		response.setContentType("text/plain");
		response.getWriter().append("Served @: ").append(this.randomUtil.randomIdentifier());
	}
	@EJB
	private Messages messages;
	// http://tomee.apache.org/jms-resources-and-mdb-container.html
//	@Resource(name = "AmqJmsConnectionFactory")
//	private ConnectionFactory connectionFactory;
}
